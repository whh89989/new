

import java.io.File;
import java.io.IOException;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.common.Weighting;
import org.apache.mahout.cf.taste.eval.IRStatistics;
import org.apache.mahout.cf.taste.eval.RecommenderBuilder;
import org.apache.mahout.cf.taste.eval.RecommenderEvaluator;
import org.apache.mahout.cf.taste.eval.RecommenderIRStatsEvaluator;
import org.apache.mahout.cf.taste.impl.eval.AverageAbsoluteDifferenceRecommenderEvaluator;
import org.apache.mahout.cf.taste.impl.eval.GenericRecommenderIRStatsEvaluator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.EuclideanDistanceSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.UncenteredCosineSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;

public class Evaluate {
	private static final String inputFile = "/home/hadoop/dataset/test.txt";

	public void getPrecisionAndRecall() throws TasteException, IOException {
		// dRandomUtils.useTestSeed();
		DataModel model = new FileDataModel(new File(inputFile));
		
		RecommenderIRStatsEvaluator evaluator = new GenericRecommenderIRStatsEvaluator();
		// 可以替换为其他的recommender
		RecommenderBuilder recommenderBuilder = new RecommenderBuilder() {

			public Recommender buildRecommender(DataModel model)
					throws TasteException {
				ItemSimilarity similarity = new UncenteredCosineSimilarity(model);
				return new GenericItemBasedRecommender(model, similarity);
			}

		};
		IRStatistics stats = evaluator.evaluate(recommenderBuilder, null,
				model, null, 2,
				GenericRecommenderIRStatsEvaluator.CHOOSE_THRESHOLD, 1.0);
		System.out.println(stats.getPrecision());
		System.out.println(stats.getRecall());
	}

	public void getScore() {
		// only used in examples for repeatable result
		// RandomUtils.useTestSeed();
		DataModel model = null;
		try {
			model = new FileDataModel(new File(inputFile));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		RecommenderEvaluator evaluator = new AverageAbsoluteDifferenceRecommenderEvaluator();
		RecommenderBuilder builder = new RecommenderBuilder() {
			// Builds the same Recommender as RecSys.java

			public Recommender buildRecommender(DataModel model)
					throws TasteException {
				//ItemSimilarity similarity = new EuclideanDistanceSimilarity(model);
				//ItemSimilarity similarity = new UncenteredCosineSimilarity(model);
				// 基于皮尔逊相关系数计算相似度
				ItemSimilarity similarity = new PearsonCorrelationSimilarity(model,Weighting.WEIGHTED);
				// 100 10
				 //UserNeighborhood neighborhood = new NearestNUserNeighborhood(2, similarity, model);
				return new GenericItemBasedRecommender(model, similarity);
			}
		};
		double score = 0;
		try {
			// Use 90% of data to train; test with other 10%
			score = evaluator.evaluate(builder, null, model, 0.90, 1.0);
		} catch (TasteException e) {
			e.printStackTrace();
		}
		System.out.println(score);
	}

	public static void main(String[] args) {
		Evaluate eval = new Evaluate();
		try {
			eval.getScore();
			System.out.println("~~~fam: getScore ok~~~~~~~~~~~~~~~~~~~~~~");
//			eval.getPrecisionAndRecall();
//			System.out.println("~~~fam:getPrecisionAndRecall ok~~~~~~~~~~~~~~~~~~~~~~");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}