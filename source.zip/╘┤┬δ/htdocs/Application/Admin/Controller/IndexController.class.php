<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function index(){
 		$m=D('admin');
 		//$attr = $m->where("username='fengamin'")->select();//调用方法查询所有的数据，返回二维数组，把数组注册到模板里
        //$a['username'] = $username;
        $value = session('admin.username');
        $a['username'] = $value;
        $attr = $m->where($a)->select();
        //$attr = $m->where("username='".$username"'")->select();
//$attr = $m->where("username='$username'")->select();
        $this->assign("info",$attr);
          $n=D('result');
         $value1= $n->where()->getField('uid');
          $b['uid']=$value1;
          $attr1=$n->where($b)->select();
          $this->assign("info1",$attr1);
          $d=D('movie');
          $c['mid']=$attr1;
          $attr2=$d->where($c)->select();
          $this->assign("info2",$attr2);
    $this->display();//载入首页面
    }
}