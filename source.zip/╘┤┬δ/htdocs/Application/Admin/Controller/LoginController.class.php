<?php
 namespace Admin\Controller;
 use Think\Controller;
 /**
 * 
 */
 class LoginController extends Controller
 {
 	public function login(){
 		//显示登陆页面并进行验证
 		if(IS_POST){
 			 //验证
 			 $username=I('username');
 			 
 			 $password=I('password');
 			 
 			 $captcha=I('captcha');
 			 
 			 $verify=new \Think\Verify();
 			 
 			 if(!$verify->check($captcha))
 			 {
 			 	$this->error('验证码错误');
 			 }
 			 if(D('admin')->checkUser($username,$password))
 			 {
 			 	$this->success('登陆成功',U('index/index'));
 			 }
 			 else
 			 {
 			 	$this->error('用户名或密码错误');
 			 }
 			 return;
 		}
 			$this->display();	
 	}
 	
 	public function code(){
 		ob_clean();
 		$Verify = new \Think\Verify();
 		$Verify->fontSize = 35;
 		$Verify->length = 4;
 		$Verify->entry();
 	}
 	public function logout(){
		session('[destroy]'); // 销毁session
		$this->success('注销成功',U('Login/login'),1);
	}
	
 }