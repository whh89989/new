<?php
namespace Admin\Model;
use Think\Model;
/**
* 
*/
class AdminModel extends Model
{
	public function checkUser($username,$password){
		
		$condition['username']=$username;
		
		$condition['password']=$password;
		
		if($admin = $this->where($condition)->find())
		{
			
			session('admin',$admin);
			
			return ture;
		}
		else
		{
			
			return false;
		}
	}
	
}