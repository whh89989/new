<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>电影推荐系统登陆界面</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="电影推荐系统登陆界面view">
    <meta name="author" content="于海婧">
    <link type="text/css" href="<?php echo (ADMIN_PUBLIC); ?>/css/houtai.css" rel="stylesheet">
    <link type="text/css" href="<?php echo (ADMIN_PUBLIC); ?>/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="big_box">
    <img  id="background" src="<?php echo (ADMIN_PUBLIC); ?>/images/首2.jpg">
    <div class="denglu_box">
        <div class="logo_box">
                <p>电影推荐系统登陆</p>
        </div>
            <div class="biandan_box">
                <form action="" method="post">
                    <div class="divclass">
                        <label class="font">UserId：&nbsp;</label>
                        <input  class="nameclass" type="text" placeholder="请在此处输入用户名" name="username">
                    </div>
                    <div class="divclass">
                        <label class="font">PassWord：</label>
                        <input class="passwordclass" type="password" placeholder="请在此处输入密码" name="password">
                    </div>
                    <div class="divclass">
                        <label class="font">验&nbsp;证&nbsp;码：</label>
                        <input class="yanzhengclass" type="text" placeholder="请输入验证码" name="captcha">
                        <img src="/index.php/admin/login/code" border="1" style="width: 200px;height: 50px;margin-top: 10px;cursor:pointer;" onClick="this.src=this.src+'?'+Math.random()">
                        <p>（看不清？点击更换）</p>
                    </div>
                    <hr class="hrclass">
                    <div class="divclass">
                        <input class="btn btn-default btn-lg" type="submit" value="&nbsp;&nbsp;登&nbsp;&nbsp;陆&nbsp;&nbsp;">
                        <input class="btn btn-default btn-lg" type="reset" value="&nbsp;&nbsp;重&nbsp;&nbsp;置&nbsp;&nbsp;">
                    </div>
                </form>
            </div>
    </div>
</div>
</body>
</html>