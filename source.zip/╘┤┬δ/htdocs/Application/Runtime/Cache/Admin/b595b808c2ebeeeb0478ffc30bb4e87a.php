<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>电影推荐系统</title>
    <meta name="description" content="电影推荐系统">
    <meta name="author" content="于海婧">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo (ADMIN_PUBLIC); ?>/css/bootstrap.min.css">
    <script type="text/javascript" src="<?php echo (ADMIN_PUBLIC); ?>/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo (ADMIN_PUBLIC); ?>/js/jquery-2.1.4.min.js"></script>
</head>
<body>
    <div class="navbar navbar-default">
        <div class="navbar-brand">
        <span style="font-size:25px;margin-left:200px;">电影推荐系统</span>
        </div>
        <div style="float:right;font-size:20px;with:200px;height:30px;text-align:center;margin-top:5px;margin-right:200px;">欢迎：<?php echo ($_SESSION['admin']['username']); ?><button style="width:100px;height:30px;text-align:center;margin-top:5px;margin-left:30px;"><a href="/index.php/admin/Login/logout" >退出</a></button>
        </div>
    </div>
    <p style="text-align:center;font-size:30px;">我 们 为 您 推 荐 如 下 电 影</p>
    <table border="3px" style="text-align:center;font-size:20px;width:800px;height:300px;margin:auto auto;">
        <tr>
            <td>电影名称</td>
            <td>电影类别</td>
            <td>电影评分</td>
            <td>上映年份</td>
        </tr>
        <?php if(is_array($info2)): foreach($info2 as $key=>$v): ?><tr>
            <td><?php echo ($v["title"]); ?></td>
            <td><?php echo ($v["genres"]); ?></td>
            <td><?php echo ($v["year"]); ?></td>
            <td><?php echo ($v["year"]); ?></td>
        </tr><?php endforeach; endif; ?>
    </table>
</body>
</html>